package or.cap.model;

public class EquipmentRecord {
	
	private String equipTag;
	private long seqNumber;
	private int userId;
	private int machineId;
	private String location;
	private String user;
	private int quantity;
	private String equipType;
	
}
