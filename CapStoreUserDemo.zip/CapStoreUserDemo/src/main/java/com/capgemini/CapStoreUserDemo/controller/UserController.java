package com.capgemini.CapStoreUserDemo.controller;


import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;


import com.capgemini.CapStoreUserDemo.model.ManagingCart;

@Controller
public class UserController {
	
	
	
	@RequestMapping("/display")
	public String getCart(ModelMap map) {
		
		
		final String uri="http://localhost:8089/Cart/api/v1/products/1";
		RestTemplate restTemplate=new RestTemplate();
		
		ManagingCart[] carts= restTemplate.getForObject(uri, ManagingCart[].class);
		
		//ManagingCart cart= restTemplate.getForObject(uri, ManagingCart.class);
		map.put("carts",carts);
		map.put("mCart", new ManagingCart());
		
		return "cart";
	}
	
	
	@GetMapping("/delete/{cartId}")
	public String deletePilot(@PathVariable("cartId") Integer cartId) {
		
		
		final String uri="http://localhost:8089/Cart/api/v1/products/{cartId}";
		RestTemplate restTemplate=new RestTemplate();
		
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("cartId", cartId);
		
		
		restTemplate.delete(uri,params);
		
		return "redirect:/display";
	}
	

}
