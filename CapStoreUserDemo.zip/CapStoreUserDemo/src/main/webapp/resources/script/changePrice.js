function changePrice(){
	var qty=document.quantity.value;
	var price=document.ppp.value;
	
	var total=qty*price;
	  
	document.getElementById("tp").value = total;
	
	
}