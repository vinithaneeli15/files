package recordUpdation;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	@Given("^valid user details$")
	public void valid_user_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to update the records$")
	public void user_is_trying_to_update_the_records() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^system enforce requirements of the equipment Type properties$")
	public void system_enforce_requirements_of_the_equipment_Type_properties() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^user is an authorized one$")
	public void user_is_an_authorized_one() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^end date has not expired$")
	public void end_date_has_not_expired() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^valid location is provided$")
	public void valid_location_is_provided() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the location is assigned to an equipment record$")
	public void the_location_is_assigned_to_an_equipment_record() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^valid user is provided$")
	public void valid_user_is_provided() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the user is assigned to an equipment record$")
	public void the_user_is_assigned_to_an_equipment_record() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
