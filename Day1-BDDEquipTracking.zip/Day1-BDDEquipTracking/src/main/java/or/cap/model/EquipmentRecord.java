package or.cap.model;

public class EquipmentRecord {
	
	private String equipTag;
	private long seqNumber;
	private int userId;
	private int machineId;
	private String location;
	private String user;
	private int quantity;
	private String equipType;
	
	public EquipmentRecord(String equipTag, long seqNumber, int userId, int machineId, String location, String user,
			int quantity, String equipType) {
		super();
		this.equipTag = equipTag;
		this.seqNumber = seqNumber;
		this.userId = userId;
		this.machineId = machineId;
		this.location = location;
		this.user = user;
		this.quantity = quantity;
		this.equipType = equipType;
	}
	
	public EquipmentRecord() {
		super();
	}

	public String getEquipTag() {
		return equipTag;
	}
	public void setEquipTag(String equipTag) {
		this.equipTag = equipTag;
	}
	public long getSeqNumber() {
		return seqNumber;
	}
	public void setSeqNumber(long seqNumber) {
		this.seqNumber = seqNumber;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getMachineId() {
		return machineId;
	}
	public void setMachineId(int machineId) {
		this.machineId = machineId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getEquipType() {
		return equipType;
	}
	public void setEquipType(String equipType) {
		this.equipType = equipType;
	}
	
}
