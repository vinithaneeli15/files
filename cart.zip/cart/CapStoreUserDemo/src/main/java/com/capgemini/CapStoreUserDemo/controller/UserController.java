package com.capgemini.CapStoreUserDemo.controller;


import java.util.HashMap;

import javax.validation.Valid;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;


import com.capgemini.CapStoreUserDemo.model.ManagingCart;

import ch.qos.logback.core.net.SyslogOutputStream;

@Controller
public class UserController {
	
	ManagingCart cart;
	
	
/*	@RequestMapping("/updateCart")
	public String getProductPage(@Valid @ModelAttribute("Cart")ManagingCart c) {
		System.out.println(c.getQuantity());
		System.out.println(c.getCart_id());
			System.out.println("========================================");
			final String uri="http://localhost:8083/Cart/api/v1/products";
			RestTemplate restTemplate=new RestTemplate();
			
			java.util.Map<String, Object> params=new HashMap<>();
			//params.put("cartId", c.getCart_id());
			
			
			//c.setQuantity(c.getQuantity());
			//restTemplate.put(uri, c, ManagingCart.class);
			restTemplate.put(uri, c, ManagingCart.class);
			cart=c;
		
		
		
		return "ShippingAddress";
	}*/
	@RequestMapping("/shipping")
	public String getPrice(@RequestParam("price") Double price) {
		
		double p=price;
		
		return "ShippingAddress";
	}
	@RequestMapping("/")
	public String displayPage(ModelMap map)
	{
		map.put("prod", 2);
		return "product";
	}
	
	
	@RequestMapping("/display")
	public String getPage() {
		
		
		
		return "redirect:/cartUser/1";
	}
	
	
	@RequestMapping("/cartUser/{custId}")
	public String getCart(ModelMap map,@PathVariable("custId") Integer custId, @ModelAttribute("cart")ManagingCart c) {
		
		System.out.println("==================================");
		final String uri="http://localhost:8083/Cart/api/v1/getproducts/{custId}";
		RestTemplate restTemplate=new RestTemplate();
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("custId", custId);
		
		ManagingCart[] carts= restTemplate.getForObject(uri, ManagingCart[].class,params);
		
		//ManagingCart cart= restTemplate.getForObject(uri, ManagingCart.class);
		map.put("cartMap",carts);
		System.out.println("---------------------------------------------------");
		map.addAttribute("cart", new ManagingCart());
		map.put("mCart", new ManagingCart());
		
		return "cart";
	}
	
	  
	
	@RequestMapping("/addingProduct/{proId}")
	public String addProduct(
			@Valid @ModelAttribute("cart") ManagingCart cart,
			BindingResult result,@PathVariable("proId") Integer proId) {
		if(!result.hasErrors()) {
			
			final String uri="http://localhost:8083/Cart/api/v1/addToCart/{proId}";
			RestTemplate restTemplate=new RestTemplate();

			java.util.Map<String, Object> params=new HashMap<>();
			params.put("proId", proId);
		//	ResponseEntity<Pilot> pilot1=
					restTemplate.postForEntity(uri,cart,ManagingCart.class,params);
		
		}
		
		return "redirect:/display";
	}
	
	@RequestMapping("/cartUser/delete/{cartId}")
	public String deleteProduct(@PathVariable("cartId") Integer cartId) {
		
		
		final String uri="http://localhost:8083/Cart/api/v1/products/{cartId}";
		RestTemplate restTemplate=new RestTemplate();
		
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("cartId", cartId);
		
		
		restTemplate.delete(uri,params);
		
		return "redirect:/display";
	}

	/*@RequestMapping("/cartUser/upqty/{q}")
	public String updateOrder(@Valid @ModelAttribute("cart")ManagingCart c,@RequestParam("quan") String qty1,
			@PathVariable("q") String qty) {
		System.out.println("===========================hi================");
		int t=Integer.parseInt(qty);
		//if(!result.hasErrors())	{
		System.out.println("----------------------------------------quantity is:----------------------------"+t);
		
		
		final String uri="http://localhost:8089/Cart/api/v1/products/1";
		RestTemplate restTemplate=new RestTemplate();
		java.util.Map<String, Object> params=new HashMap<>();
		//params.put("custId", custId);
		
		ManagingCart[] carts= restTemplate.getForObject(uri, ManagingCart[].class,params);
		System.out.println(carts[0]);
		final String uri1="http://localhost:8089/Cart/api/v1/products";
			RestTemplate restTemplate1=new RestTemplate();
			//o1.setDeliveredDate(new Date());
        carts[0].setQuantity(t);
			//c.setQuantity(t);
			restTemplate.postForEntity(uri1,c,ManagingCart.class);
			//restTemplate.put(uri,c,ManagingCart.class);
			//cart=c;*/
			
		//}
		//return "redirect:/display";
	//}*/
	/*@RequestMapping(value="/cartUser/upqty")
	public String updateQ(@Valid @ModelAttribute("Cart")ManagingCart c) {
		System.out.println(c.getQuantity());
	System.out.println(c.getCart_id());
		System.out.println("========================================");
		final String uri="http://localhost:8089/Cart/api/v1/products/{cartId}";
		RestTemplate restTemplate=new RestTemplate();
		
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("cartId", c.getCart_id());
		
		
		c.setQuantity(c.getQuantity());
		//restTemplate.put(uri, c, ManagingCart.class);
		restTemplate.postForEntity(uri, c, ManagingCart.class);
		cart=c;
		return "redirect:/display";
	}*/

}
