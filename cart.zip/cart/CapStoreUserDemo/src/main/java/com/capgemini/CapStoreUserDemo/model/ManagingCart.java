package com.capgemini.CapStoreUserDemo.model;

//import com.fasterxml.jackson.annotation.JsonIgnore;

public class ManagingCart {
	
	private int cart_id;
	
	

	private Inventory inventory;
	

	private Customer customers;
	
	
	private int quantity;
	private String status;
	

	


public ManagingCart() {
	
}


public ManagingCart(int cart_id, Customer customers, Inventory inventory, int quantity, String status) {
	super();
	this.cart_id = cart_id;
	this.customers = customers;
	this.inventory = inventory;
	this.quantity = quantity;
	this.status = status;
}


public int getCart_id() {
	return cart_id;
}


public void setCart_id(int cart_id) {
	this.cart_id = cart_id;
}


public Customer getCustomers() {
	return customers;
}


public void setCustomers(Customer customers) {
	this.customers = customers;
}


public Inventory getInventory() {
	return inventory;
}


public void setInventory(Inventory inventory) {
	this.inventory = inventory;
}


public int getQuantity() {
	return quantity;
}


public void setQuantity(int quantity) {
	this.quantity = quantity;
}


public String getStatus() {
	return status;
}


public void setStatus(String status) {
	this.status = status;
}








}
