package com.capgemini.CapStoreUserDemo.controller;

import java.util.HashMap;

import javax.validation.Valid;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.CapStoreUserDemo.model.ManagingCart;

@Controller
public class BuyNowUserController {
	
	/*@RequestMapping("/productPage")
	public String getProductPage() {
		return "product";
	}*/
	

	/*@RequestMapping("/buyNow/{custId}")
public String getCart(ModelMap map,@PathVariable("custId") Integer custId) {
		
		
		final String uri="http://localhost:8089/Cart/api/v1/buyNow/{custId}";
		RestTemplate restTemplate=new RestTemplate();
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("custId", custId);
		
		
		
		restTemplate.getForObject(uri, ManagingCart[].class,params);
		
		//ManagingCart cart= restTemplate.getForObject(uri, ManagingCart.class);
		//map.put("carts",carts);
		//map.addAttribute("cart", new ManagingCart());
		//map.put("mCart", new ManagingCart());
		
		return "ShippingAddress";
	}*/
	
	@RequestMapping("/buyNow")
	public String updatePilot(
			@Valid @ModelAttribute("cart") ManagingCart cart,
			BindingResult result) {
		if(!result.hasErrors()) {
			
			final String uri="http://localhost:8083/Cart/api/v1/buyNow/1";
			RestTemplate restTemplate=new RestTemplate();
			
		//	ResponseEntity<Pilot> pilot1=
					restTemplate.postForEntity(uri,cart,ManagingCart.class);
		
		}
		
		return "ShippingAddress";
	}
	
	
	
}
