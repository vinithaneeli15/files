package com.capgemini.CartDemoRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.capgemini.CartDemoRest.model.ManagingCart;
import com.capgemini.CartDemoRest.service.ICartService;


@RestController
@RequestMapping("/api/v1")
public class MyController {
	
	@Autowired
	 private ICartService cartService;
	
	@GetMapping("/products")
	public ResponseEntity<List<ManagingCart>> getCart() {
		List<ManagingCart> managingCart = cartService.getAll();
		
		//System.out.println("Products:" + managingCart);
		if(managingCart == null || managingCart.isEmpty()) {
			return new ResponseEntity("Cart is not available", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<ManagingCart>>(managingCart, HttpStatus.OK);
	}
	
	
	/*@PostMapping("/products")
	public void navigateToCartPage(@ModelAttribute("product") Inventory product) {
		
		
		
		ManagingCart cart=new ManagingCart();
		
		
		cartService.addToCart(cart);
		
	}*/
	
	/*@PostMapping("/products")
	public ResponseEntity<ManagingCart> createWishList(@RequestBody ManagingCart managingCart) {
		cartService.save(managingCart);
		return new ResponseEntity<ManagingCart>(HttpStatus.OK);
	}*/
}
