package com.capgemini.CartDemoRest.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.CartDemoRest.model.ManagingCart;
@Repository("cartDao")
@Transactional
public interface ICartDao extends JpaRepository<ManagingCart, Integer>{
	
	/*@Query("select productId from ManagingCart ")
	List<Integer> findProducts();*/
	
	
	
	/*@Query("select (cart_id,quantity,productId,custId,status) from ManagingCart where inventory.proId=:productId")
	 void create(ManagingCart managingCart);
*/

	
	/*@Query("select inventory.productId from WishList where customers.custId=:customerId ")
	public List<Integer> findProducts(@Param("customerId")int custId); */
}
