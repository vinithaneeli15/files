package com.cap.WishList.service;

import java.util.List;

import com.cap.WishList.modal.Customer;
import com.cap.WishList.modal.Inventory;
import com.cap.WishList.modal.WishList;

public interface WishListService {

	public List<Integer> getAll(int custId);
public void save(WishList wishList);
	/*public List<WishList> deleteWishList(Integer wishId);
	public WishList getOne(Integer customerId)*/;

}
