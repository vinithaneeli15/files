package com.cap.WishList.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cap.WishList.dao.InventoryDao;
import com.cap.WishList.dao.WishListDao;
import com.cap.WishList.dao.CustomerDao;
import com.cap.WishList.modal.Customer;
import com.cap.WishList.modal.Inventory;
import com.cap.WishList.modal.WishList;


@Service("wishListService")
public class WishListServiceImpl implements WishListService{
	
	
	@Autowired
	private WishListDao wishListDao;
	
	
	@Override
	public List<Integer> getAll(int custId) {
		/*Inventory inventory=new Inventory();
		inventory.setProductName("LG");
		
		Inventory inventory1=new Inventory();
		inventory1.setProductName("Godrej");
		
		Customer customer=new Customer();
		customer.setCustName("Tom");
		
		Customer Jerry=new Customer();
		Jerry.setCustName("Jerry");
		
		inventoryDao.save(inventory);
		inventoryDao.save(inventory1);
		
		wishListDao.save(customer);
		wishListDao.save(Jerry);
		
		List<Inventory> list=new ArrayList<>();
		list.add(inventory1);
		list.add(inventory);
		
		customer.setInventories(list);
		wishListDao.save(customer);*/
		
		/*Jerry.getInventories().add(inventory1);
		Jerry.getInventories().add(inventory);
		
		customer.getInventories().add(inventory);*/
		
		
		//wishListDao.save(inventory);
		
		
		
		return wishListDao.findProducts(custId);
	}
	
	

	@Override
	public void save(WishList wishList) {
		wishListDao.save(wishList);
	}

	/*@Override
	public List<WishList> deleteWishList(Integer wishId) {
		wishListDao.deleteById(wishId);
		return wishListDao.findAll();
	}

	@Override
	public WishList getOne(Integer customerId) {
		return wishListDao.getOne(customerId);
	}
*/
	
}
