package com.cap.WishList.modal;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "created"})
public class Customer {
	@Id
	@GeneratedValue
	private int custId;
	private String custName;
	
	@OneToMany(targetEntity=WishList.class,mappedBy="customers")
	private List<WishList> wishList;

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public List<WishList> getWishList() {
		return wishList;
	}

	public void setWishList(List<WishList> wishList) {
		this.wishList = wishList;
	}

	public Customer(int custId, String custName, List<WishList> wishList) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.wishList = wishList;
	}
	public Customer() {
		
	}
	
	
	
}
