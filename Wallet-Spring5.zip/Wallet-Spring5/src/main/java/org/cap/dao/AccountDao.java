package org.cap.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface AccountDao {

	void createAccount(Account account);
   public List<Account> getAllAccounts(int customerId);
   List<Long> deposit(int customerId);
   void depositOrWithdraw(Transaction transaction);
   public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId);
     public Account getAccount(long accNo);
	 public List<Account> getAllToAccounts(Integer customerId);
	void fundTransfer(Transaction transaction);
	Account getAccount1(long accNo1);
	/*List<Transaction> getTransactions(Integer customerId, Date fromDate, Date toDate);*/
	List<Transaction> getTransactions(int customerId);

}
