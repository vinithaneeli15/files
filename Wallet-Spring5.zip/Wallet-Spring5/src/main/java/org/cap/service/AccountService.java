package org.cap.service;

import java.util.Date;
import java.util.List;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface AccountService {



	void createAccount(Account account);

	List<Account> getAllAccounts(Integer custId);

	List<Long> deposit(int customerId);

	void depositOrWithdraw(Transaction transaction);
	public List<Account> getAccountWithBalance(int custId);

	public Account getAccount(long accNo);

	public List<Account> getAllToAccounts(Integer customerId);

	void fundTransfer(Transaction transaction);

	Account getAccount1(long accNo1);

	/*List<Transaction> getTransactions(Integer customerId, Date fromDate, Date toDate);*/

	List<Transaction> getTransactions(int customerId);

}
