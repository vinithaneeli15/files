package Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailsBean {
   WebDriver driver;
	
	
	@FindBy(name="chname",how=How.NAME)
	private WebElement holderName;
	
	@FindBy(name="cnumber",how=How.NAME)
	private WebElement cardNo;
	
	@FindBy(name="cvvnumber",how=How.NAME)
	private WebElement cvv;
	
	@FindBy(name="edate",how=How.NAME)
	private WebElement date;
	

	@FindBy(name="payment",how=How.NAME)
	private WebElement regBtn;
	
	
	public PaymentDetailsBean(WebDriver driver) {
		this.driver=driver;
		
		//extra
	   PageFactory.initElements(driver, this);
	}
	
	public void setHolderName(String hName) {
		//driver.findElement(userName).sendKeys(usrName);
		holderName.sendKeys(hName);
	}
	public void setCardNo(String cnumber) {
		//driver.findElement(userName).sendKeys(usrName);
		cardNo.sendKeys(cnumber);
	}
	public void setCvv(String cvvNo) {
		//driver.findElement(userName).sendKeys(usrName);
		cvv.sendKeys(cvvNo);
	}
	public void setDate(String date1) {
		//driver.findElement(userName).sendKeys(usrName);
		date.sendKeys(date1);
	}
public void setRegBtn() {
		
		regBtn.submit();
	}
	public void loginToNextPage(String hName,String card, String cvv,String date2) {
    this.setHolderName(hName);
    this.setCardNo(card);
    this.setCvv(cvv);
    this.setDate(date2);
    this.setRegBtn();
}

}
