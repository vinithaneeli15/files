package com.capgemini.CartDemoRest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.CartDemoRest.dao.ICartDao;
import com.capgemini.CartDemoRest.model.ManagingCart;

@Service("cartService")
public class ICartServiceImpl implements ICartService {
	
	@Autowired
	private ICartDao cartDao;

	@Override
	public List<ManagingCart> getAll(int proId) {
		
		return  (List<ManagingCart>) cartDao.findProduct(proId);
		
	}
/*
	@Override
	public void addToCart(ManagingCart cart) {
		
		cartDao.save(cart);
		
	}
*/
	/*@Override
	public void save(ManagingCart managingCart) {
		// cartDao.create(managingCart);
		cartDao.save(managingCart);
		
	}*/

	
   
	
	
	
}
