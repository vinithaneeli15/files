package com.capgemini.CartDemoRest.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.CartDemoRest.model.ManagingCart;
@Repository("cartDao")
@Transactional
public interface ICartDao extends JpaRepository<ManagingCart, Integer>{
	
	
	
	@Query("select cart_id,quantity,status,m.customers.custId,m.inventory.productId from ManagingCart m where m.customers.custId=:customerId")
	public List<ManagingCart> findProduct(@Param("customerId")int custId); 
	
	/*@Query("select productId from ManagingCart ")
	List<Integer> findProducts();*/
	
	
	
	/*@Query("select (cart_id,quantity,productId,custId,status) from ManagingCart where inventory.proId=:productId")
	 void create(ManagingCart managingCart);
*/

	
	/*@Query("select inventory.productId from WishList where customers.custId=:customerId ")
	public List<Integer> findProducts(@Param("customerId")int custId); */
}
