package com.capgemini.CartDemoRest.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.CartDemoRest.model.ManagingCart;
@Repository("cartDao")
@Transactional
public interface ICartDao extends JpaRepository<ManagingCart, Integer>{
	
	
	
	/*@Query("select cart_id,quantity,status,m.customers.custId,m.inventory.productId from ManagingCart m where m.customers.custId=:customerId")*/
	@Query("select m from ManagingCart m where m.customers.custId=:customerId")
	public List<ManagingCart> findProduct(@Param("customerId")int customerId); 
	
	
	
	
	}
