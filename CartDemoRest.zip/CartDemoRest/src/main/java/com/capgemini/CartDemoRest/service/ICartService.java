package com.capgemini.CartDemoRest.service;

import java.util.List;

import com.capgemini.CartDemoRest.model.ManagingCart;

public interface ICartService {

	 public List<ManagingCart> getAll(int proId);

	//public void addToCart(ManagingCart cart);

	//public void save(ManagingCart managingCart);

}
