package org.cap.dao;

import org.cap.model.Account;

public interface AccountDao {
 public boolean addAccount(Account account);
}
