package org.cap.exception;

public class InvalidOpeningBalance extends Exception{

	public InvalidOpeningBalance(String string) {
		super(string);
	}

}
