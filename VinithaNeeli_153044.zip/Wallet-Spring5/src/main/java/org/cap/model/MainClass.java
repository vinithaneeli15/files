package org.cap.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=factory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Customer customer3=new Customer();
		customer3.setCustomerPwd("tom123");
		customer3.setFirstName("Tom");
		customer3.setLastName("Jerry");
		customer3.setLastLoginDate(new Date());
		
		
		Account account=new Account();
		account.setAccountNo(12345678996L);
		account.setAccountType("savings");
		
	
		account.setCustomer(customer3);
		
		Account account1=new Account();
		account1.setAccountNo(12345678997L);
		account1.setAccountType("current");
		account1.setCustomer(customer3);
		account1.setStatus("active");
		
		
		Transaction transaction2=new Transaction();
		transaction2.setCustomer(customer3);
		transaction2.setFromAccount(account);
		transaction2.setAmount(1000);
		transaction2.setTransactionType("debit");
		transaction2.setTransactionDate(new Date("2018/07/26"));
		transaction2.setDescription("deposit");
		
		Transaction transaction3=new Transaction();
		transaction3.setCustomer(customer3);
		transaction3.setFromAccount(account);
		transaction3.setToAccount(account1);
		transaction3.setAmount(1000);
		transaction3.setTransactionType("credit");
		transaction3.setTransactionDate(new Date("2018/07/26"));
		transaction3.setDescription("deposit");
		
		entityManager.persist(customer3);
		entityManager.persist(account);
		entityManager.persist(account1);
		entityManager.persist(transaction2);
		entityManager.persist(transaction3);
		transaction.commit();


	}

}
