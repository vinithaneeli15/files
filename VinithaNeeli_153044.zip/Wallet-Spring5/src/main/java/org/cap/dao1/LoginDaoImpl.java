package org.cap.dao1;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.cap.model.Customer;
import org.springframework.stereotype.Repository;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public boolean validateLogin(int customerId, String password) {
		 
		Query query=entityManager.createQuery("from Customer where customerId=? and customerPwd=?");
		query.setParameter(0,customerId);
		query.setParameter(1,password);
		List<Customer> customers=query.getResultList();
		if(!customers.isEmpty())
			return true;
		else
		return false;
	}

	@Override
	public String getCustomerName(int customerId) {
		Query query=entityManager.createQuery(" select cust.firstName from Customer cust where customerId=?");
		query.setParameter(0,customerId);
		List<String> customers=query.getResultList();
		
		return customers.get(0);
	}

	
}
