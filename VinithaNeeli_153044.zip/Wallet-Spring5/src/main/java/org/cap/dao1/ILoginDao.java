package org.cap.dao1;

public interface ILoginDao {
  public boolean validateLogin(int customerId,String password);
  public String getCustomerName(int customerId);
}
