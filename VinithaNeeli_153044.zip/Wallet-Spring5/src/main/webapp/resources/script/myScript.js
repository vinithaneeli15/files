/*window.onload=function(){

	document.getElementById('withdraw').style.display='none';
	document.getElementById('deposit').style.display='block';
}*/
function showOption(){
	if(document.getElementById('deposit').checked )	
		
		
			document.getElementById('button').value="Deposit";
	else
		document.getElementById('button').value="Withdraw";
		
		
	
	/*
	if(document.getElementById('deposit').checked )	{
		document.getElementById('withOpt').style.display='none';
		document.getElementById('depoOpt').style.display='block';
	}
	else if(document.getElementById('withdraw').checked ){
		document.getElementById('withOpt').style.display='block';
		document.getElementById('depoOpt').style.display='none';
	}
	else{

		document.getElementById('withOpt').style.display='none';
		document.getElementById('depoOpt').style.display='none';
	}*/
}
window.onload=function(){
	document.getElementById('yearsDiv').style.display='none';
}
function showYearsDiv() {
	if(document.getElementById('rd').checked || document.getElementById('fd').checked)	{
		document.getElementById('yearsDiv').style.display='block';
	}
	else
		document.getElementById('yearsDiv').style.display='none';
}
function validateForm1(){
	var desc=myform1.description.value;
	var amt=myform1.amount.value;
	var flag=false;
	if(desc==""||desc==null){
		flag=false;
		document.getElementById('descErrMsg').innerHTML="*Please enter description";
	}
	else if(amt==0||amt==null){
		flag=false;
		document.getElementById('descErrMsg').innerHTML="";
		
		document.getElementById('amtErrMsg').innerHTML="*Please enter amount";
	}
	else{
		flag=true;
      document.getElementById('descErrMsg').innerHTML="";
		
		document.getElementById('amtErrMsg').innerHTML="";
	}
	
	return flag;
}
function validateForm(){
	var uname=myform.username.value;
	var upwd=myform.password.value;
	var flag=false;
	if(uname==""||uname==null){
		flag=false;
		document.getElementById('userErrMsg').innerHTML="*Please enter Customer Id";
	}
	else if(upwd==""||upwd==null){
		flag=false;
		document.getElementById('userErrMsg').innerHTML="";
		
		document.getElementById('pwdErrMsg').innerHTML="*Please enter password";
	}
	else{
		flag=true;
      document.getElementById('userErrMsg').innerHTML="";
		
		document.getElementById('pwdErrMsg').innerHTML="";
	}
	
	return flag;
}
function openingBal() {
    var opnBal=accform.openingBalance.value;
    var flag=false;
    if(document.getElementById('rd').checked)
           {
           if (opnBal<=500 || opnBal==null) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open RD is 500.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
           }
    else if (document.getElementById('fd').checked) {
           if (opnBal<=1000) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open FD is 1000.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
    }
    else if (document.getElementById('savings').checked) {
           if (opnBal<=1000) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Savings Acc is 500.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
    }
    else if (document.getElementById('current').checked) {
           if (opnBal<=10000) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Current Acc is 10000.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
    }
    else{
           flag=true;
           document.getElementById('errMsg').innerHTML="";
    }
    return flag;
}


