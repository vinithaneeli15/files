window.onload=fuction(){
	/* var p[]=document.forms.myForm.ppp.value; */
	  //var len=document.getElementById("ppp").len;
	 // alert("work");
} 

 function test(){
	 alert("work");
 }

function changePrice(){
	/* var qty=document.forms.myForm.quantity.value;
	var price=document.forms.myForm.ppp.value; */
	//var t=0;
	var qty=document.getElementById("quantity").value;
	var price=document.getElementById("ppp").value;
	
	var total=qty*price;
	  //t=t+total;
	document.getElementById("tp").value = total;
	//document.getElementById("otp").value = t;
	
	
}

function change(){
	document.getElementById('testInput').value = "Javascript";
}

