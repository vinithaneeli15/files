package com.capgemini.CartDemoRest.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "created"})
@Table(name="managing_cart")
public class ManagingCart {
	
	@Id
	@GeneratedValue
	private int cart_id;
	
	
	@ManyToOne
	@JoinColumn(name="product_id")
	private Inventory inventory;
	
	
	@ManyToOne
	@JoinColumn(name="cust_id")
	private Customer customers;
	
	
	private int quantity;
	private String status;
	







public ManagingCart() {
	
}


public ManagingCart(int cart_id, Customer customers, Inventory inventory, int quantity, String status) {
	super();
	this.cart_id = cart_id;
	this.customers = customers;
	this.inventory = inventory;
	this.quantity = quantity;
	this.status = status;
}


public int getCart_id() {
	return cart_id;
}


public void setCart_id(int cart_id) {
	this.cart_id = cart_id;
}


public Customer getCustomers() {
	return customers;
}


public void setCustomers(Customer customers) {
	this.customers = customers;
}


public Inventory getInventory() {
	return inventory;
}


public void setInventory(Inventory inventory) {
	this.inventory = inventory;
}


public int getQuantity() {
	return quantity;
}


public void setQuantity(int quantity) {
	this.quantity = quantity;
}


public String getStatus() {
	return status;
}


public void setStatus(String status) {
	this.status = status;
}


}
