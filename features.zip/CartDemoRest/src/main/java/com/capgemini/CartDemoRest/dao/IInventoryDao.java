package com.capgemini.CartDemoRest.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.CartDemoRest.model.Inventory;
import com.capgemini.CartDemoRest.model.ManagingCart;

public interface IInventoryDao  extends JpaRepository<Inventory, Integer>{

}
