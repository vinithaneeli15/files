package com.capgemini.CartDemoRest.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.CartDemoRest.model.Customer;
import com.capgemini.CartDemoRest.model.ManagingCart;

public interface ICustomerDao extends JpaRepository<Customer, Integer>{

}
