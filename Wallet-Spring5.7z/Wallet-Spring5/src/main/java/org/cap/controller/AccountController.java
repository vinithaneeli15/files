package org.cap.controller;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.service.AccountService;
import org.cap.service1.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class AccountController {
  @PersistenceContext
   EntityManager entityManager;
   @Autowired
   private ILoginService loginService;
   @Autowired
   private AccountService accountService;
   

	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("username")String userName,
			@RequestParam("password")String userPwd, HttpSession session ) {
		
		int customerId=Integer.parseInt(userName);
	
		if(loginService.validateLogin(customerId, userPwd)) {
			session.setAttribute("custId",customerId);
			String custName=loginService.getCustomerName(customerId);
			map.put("custName", custName);
		return "main";
		}
		return "redirect:/";
	}

	@RequestMapping("/createAccount")
	public String createAccount(ModelMap map) {
		map.put("account", new Account());
		return "createAccount";
		
	}
	
	
@RequestMapping("/saveAccount")
public String saveAccount(HttpSession session, @ModelAttribute("account") Account account) {

	account.setOpeningDate(new Date());
	Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
	Customer customer=new Customer();
	customer.setCustomerId(customerId);
	account.setStatus("active");
	account.setCustomer(customer);
	accountService.createAccount(account);
				return "redirect:/createAccount";
		
	
}
/*@RequestMapping("/showBalance")
public String showBalance(ModelMap map,HttpSession session) {
	Integer custId=Integer.parseInt(session.getAttribute("custId").toString());
	List<Account> accounts=accountService.getAllAccounts(custId);
	map.put("accounts",accounts);
	return "showBalance";
	
}*/
@RequestMapping("/showBalance")
public String showBalanceDetails(ModelMap map,
		HttpSession session) {
	
	Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
	List<Account> accounts= accountService.getAccountWithBalance(custId);
	
	map.put("accounts", accounts);
	
	return "showBalance";
}
@RequestMapping("/deposit")
public String deposit(ModelMap map,HttpSession session,	@ModelAttribute("transaction") Transaction transaction) {
	
	Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
	
	
	
	
	 List<Long> accountNos=accountService.deposit(customerId);
	 map.put("accNos",accountNos);
	return "deposit";
	
}


@RequestMapping("/depositOrWithdraw")
public String depositOrWithdraw(ModelMap map,HttpSession session,
		@ModelAttribute("transaction") Transaction transaction) {
	transaction.setTransactionDate(new Date());
	transaction.setTransactionType("Transaction completed");
	Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
	Customer customer=new Customer();
	customer.setCustomerId(customerId);
	
	transaction.setCustomer(customer);
	accountService.depositOrWithdraw(transaction);
	
	return "redirect:/deposit";
	
}





@RequestMapping("/withdraw")
public String withdraw() {
	return "withdraw";
	
}
@RequestMapping("/printTransaction")
public String printTransaction() {
	return "printTransaction";
	
}
@RequestMapping("/fundTransfer")
public String fundTransfer() {
	return "fundTransfer";
	
}
@RequestMapping("/transSummary")
public String transSummary() {
	return "transSummary";
	
}
@RequestMapping("/logout")
public String logout(HttpSession session) {
	session.invalidate();
	return "redirect:/";
	
}




}