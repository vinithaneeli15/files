package org.cap.service1;

import org.cap.dao1.ILoginDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImpl implements ILoginService {
  @Autowired
	private ILoginDao loginDao;
	@Override
	public boolean validateLogin(int customerId, String password) {
		
		return loginDao.validateLogin(customerId, password);
	}
	@Override
	public String getCustomerName(int customerId) {
		
		return loginDao.getCustomerName(customerId);
	}

}
