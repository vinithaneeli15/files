package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface AccountService {



	void createAccount(Account account);

	List<Account> getAllAccounts(Integer custId);

	List<Long> deposit(int customerId);

	void depositOrWithdraw(Transaction transaction);
	public List<Account> getAccountWithBalance(int custId);	

}
