window.onload=function(){

	document.getElementById('withOpt').style.display='none';
	document.getElementById('depoOpt').style.display='none';
}
function showOption(){
	if(document.getElementById('depo').checked )	{
		document.getElementById('depoOpt').style.display='block';
		document.getElementById('withOpt').style.display='none';
	}
	else if(document.getElementById('with').checked ){
		document.getElementById('withOpt').style.display='block';
		document.getElementById('depoOpt').style.display='none';
	}
	else{

		document.getElementById('withOpt').style.display='none';
		document.getElementById('depoOpt').style.display='none';
	}
}
window.onload=function(){
	document.getElementById('yearsDiv').style.display='none';
}
function showYearsDiv() {
	if(document.getElementById('rd').checked || document.getElementById('fd').checked)	{
		document.getElementById('yearsDiv').style.display='block';
	}
	else
		document.getElementById('yearsDiv').style.display='none';
}

function validateForm(){
	var uname=myform.username.value;
	var upwd=myform.password.value;
	var flag=false;
	if(uname==""||uname==null){
		flag=false;
		document.getElementById('userErrMsg').innerHTML="*Please enter username";
	}
	else if(upwd==""||upwd==null){
		flag=false;
		document.getElementById('userErrMsg').innerHTML="";
		
		document.getElementById('pwdErrMsg').innerHTML="*Please enter password";
	}
	else{
		flag=true;
      document.getElementById('userErrMsg').innerHTML="";
		
		document.getElementById('pwdErrMsg').innerHTML="";
	}
	
	return flag;
}
function openingBal() {
    var opnBal=accform.openingBalance.value;
    var flag=false;
    if(document.getElementById('rd').checked)
           {
           if (opnBal<=500) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open RD is 500.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
           }
    else if (document.getElementById('fd').checked) {
           if (opnBal<=1000) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open FD is 1000.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
    }
    else if (document.getElementById('savings').checked) {
           if (opnBal<=1000) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Savings Acc is 500.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
    }
    else if (document.getElementById('current').checked) {
           if (opnBal<=10000) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Current Acc is 10000.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
    }
    else{
           flag=true;
           document.getElementById('errMsg').innerHTML="";
    }
    return flag;
}


